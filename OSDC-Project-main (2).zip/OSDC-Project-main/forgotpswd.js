// function resetPassword() {
//     // Get the email, new password and confirm password values from the form
//     const email = document.getElementById('email').value;
//     const newPassword = document.getElementById('new-password').value;
//     const confirmPassword = document.getElementById('confirm-password').value;
  
//     // Validate that the new password and confirm password match
//     if (newPassword !== confirmPassword) {
//       alert('New password and confirm password do not match');
//       return;
//     }
  
//     // Use your server-side code to update the user's password in the database
//     // This code is just an example, replace it with your own server-side code
//     fetch('/api/reset-password', {
//       method: 'POST',
//       body: JSON.stringify({ email, newPassword }),
//       headers: {
//         'Content-Type': 'application/json'
//       }
//     }).then(response => {
//       if (response.ok) {
//         alert('Password reset successful');
//       } else {
//         alert('Password reset failed');
//       }
//     }).catch(error => {
//       console.error(error);
//       alert('Password reset failed');
//     });
//   }
$(".input_text").focus(function(){
    $(this).prev('.fa').addclass('glowIcon')
})
$(".input_text").focusout(function(){
    $(this).prev('.fa').removeclass('glowIcon')
})